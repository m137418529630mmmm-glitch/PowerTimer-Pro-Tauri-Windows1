import React, { useState, useEffect, useRef } from 'react';
import { invoke } from '@tauri-apps/api/core';
import { 
  Minus, 
  Square, 
  X, 
  Download, 
  RotateCcw, 
  Volume2, 
  VolumeX, 
  FileCode, 
  ShieldAlert,
  ArrowDown
} from 'lucide-react';
import { sounds } from './utils/audio';
import { ShutdownConfig } from './utils/scripts';
import { LockScreen } from './components/LockScreen';
import { ExportExeModal } from './components/ExportExeModal';
import { MediaLabLogo } from './components/MediaLabLogo';

type ActionType = 'shutdown' | 'restart' | 'lock' | 'sleep';

export default function App() {
  const [isArabic, setIsArabic] = useState<boolean>(true);
  
  // Timer Configuration
  const [actionType, setActionType] = useState<ActionType>('shutdown');
  const [inputMinutes, setInputMinutes] = useState<string>('30');
  const [forceKill, setForceKill] = useState<boolean>(true);
  const [warningSound, setWarningSound] = useState<boolean>(true);
  const [pinProtected, setPinProtected] = useState<boolean>(false);
  const [pinCode, setPinCode] = useState<string>('1234');
  
  // Running State
  const [isRunning, setIsRunning] = useState<boolean>(false);
  const [totalSeconds, setTotalSeconds] = useState<number>(30 * 60);
  const [remainingSeconds, setRemainingSeconds] = useState<number>(30 * 60);
  const [statusMessage, setStatusMessage] = useState<string>('Ready — set timer and press Start');
  
  // Modals
  const [isLockScreenActive, setIsLockScreenActive] = useState<boolean>(false);
  const [isExportModalOpen, setIsExportModalOpen] = useState<boolean>(false);
  const [soundEnabled, setSoundEnabled] = useState<boolean>(true);

  const timerRef = useRef<NodeJS.Timeout | null>(null);

  const updateDuration = (minsStr: string) => {
    setInputMinutes(minsStr);
    const parsed = parseFloat(minsStr);
    if (!isNaN(parsed) && parsed > 0) {
      const secs = Math.round(parsed * 60);
      setTotalSeconds(secs);
      setRemainingSeconds(secs);
    }
  };

  const executePowerAction = async () => {
    try {
      await invoke('execute_power_action', { action: actionType, forceKill });
    } catch (error) {
      console.error(error);
      setStatusMessage(isArabic ? 'تعذر تنفيذ الإجراء. شغّل البرنامج كمسؤول.' : 'Could not execute the action. Try running as administrator.');
    }
  };

  useEffect(() => {
    if (!isRunning || remainingSeconds <= 0) {
      if (timerRef.current) clearInterval(timerRef.current);
      return;
    }

    timerRef.current = setInterval(() => {
      setRemainingSeconds((prev) => {
        if (prev <= 1) {
          if (timerRef.current) clearInterval(timerRef.current);
          setIsRunning(false);
          sounds.playAlarm();
          setStatusMessage(isArabic ? 'انتهى الوقت — جارٍ تنفيذ الإجراء' : 'Time is up — executing action');
          void executePowerAction();
          return 0;
        }
        if (prev === 61 && warningSound) sounds.playAlarm();
        else if (prev <= 5 && warningSound) sounds.playTick();
        return prev - 1;
      });
    }, 1000);

    return () => {
      if (timerRef.current) clearInterval(timerRef.current);
    };
  }, [isRunning, warningSound, isArabic, actionType, forceKill]);

  const handleToggleTimer = () => {
    if (isRunning) {
      sounds.playCancel();
      setIsRunning(false);
      void invoke('cancel_power_action');
      setStatusMessage(isArabic ? 'تم إلغاء المؤقت' : 'Timer cancelled');
    } else {
      const mins = parseFloat(inputMinutes);
      if (isNaN(mins) || mins <= 0) {
        setStatusMessage(isArabic ? 'يرجى إدخال مدة صحيحة' : 'Please enter valid duration');
        return;
      }
      const secs = Math.round(mins * 60);
      setTotalSeconds(secs);
      setRemainingSeconds(secs);
      setIsRunning(true);
      sounds.playStart();
      setStatusMessage(
        isArabic 
          ? `قيد العد التنازلي: متبقي ${formatTime(secs)}`
          : `Running — ${formatTime(secs)} remaining`
      );
    }
  };

  const formatTime = (secs: number) => {
    const h = Math.floor(secs / 3600);
    const m = Math.floor((secs % 3600) / 60);
    const s = secs % 60;
    return `${h.toString().padStart(2, '0')}:${m.toString().padStart(2, '0')}:${s.toString().padStart(2, '0')}`;
  };

  const progressPercent = totalSeconds > 0 
    ? Math.min(100, Math.max(0, ((totalSeconds - remainingSeconds) / totalSeconds) * 100))
    : 0;

  const currentConfig: ShutdownConfig = {
    action: actionType,
    totalSeconds: isRunning ? remainingSeconds : (parseFloat(inputMinutes) || 30) * 60,
    forceKill,
    warningSound,
    pinProtected,
    pinCode,
  };

  return (
    <div className="min-h-screen bg-[#ece9e2] text-[#222] flex flex-col justify-center items-center p-2 font-sans select-none">
      
      {/* Main Desktop Card Frame */}
      <div 
        className="w-full max-w-[530px] bg-[#f4f2ee] rounded-2xl shadow-xl border border-neutral-300/80 overflow-hidden p-4 sm:p-5 space-y-3" 
        dir="ltr"
      >
          
          {/* Header Row: mediaLab publishing logo on left, category on right */}
          <div className="flex items-start justify-between">
            <MediaLabLogo />
            <div className="text-[11px] font-bold text-neutral-400 tracking-wider pt-2 uppercase">
              {isArabic ? 'مؤقت الإغلاق والقفل' : 'SHUTDOWN TIMER'}
            </div>
          </div>

          {/* Row 1: TIMER (Clean full-width input, 'Paste' button removed as requested) */}
          <div className="space-y-1.5" dir={isArabic ? 'rtl' : 'ltr'}>
            <div className="flex items-center justify-between text-[11px] font-bold text-neutral-400 tracking-wider uppercase">
              <span>{isArabic ? 'مدة المؤقت (بالدقائق)' : 'TIMER (MINUTES)'}</span>
              {isRunning && (
                <span className="text-[#e85933] font-mono font-bold text-xs">
                  {formatTime(remainingSeconds)}
                </span>
              )}
            </div>

            <div className="relative">
              <input
                type="number"
                min="1"
                disabled={isRunning}
                value={inputMinutes}
                onChange={(e) => updateDuration(e.target.value)}
                placeholder={isArabic ? '30 دقيقة' : '30 minutes'}
                className="w-full bg-white border border-neutral-300 rounded-lg px-4 py-2.5 text-sm font-semibold text-neutral-900 focus:outline-none focus:border-[#e85933] transition-colors disabled:bg-neutral-100 disabled:text-neutral-400 shadow-xs"
              />
              <span className={`absolute top-1/2 -translate-y-1/2 text-xs font-medium text-neutral-400 pointer-events-none ${isArabic ? 'left-3' : 'right-3'}`}>
                {isArabic ? 'دقيقة' : 'min'}
              </span>
            </div>
          </div>

          {/* Row 2: ACTION TYPE (Fixed English terms to proper shutdown options, no video downloader terms!) */}
          <div className="space-y-1.5" dir={isArabic ? 'rtl' : 'ltr'}>
            <div className="text-[11px] font-bold text-neutral-400 tracking-wider uppercase">
              {isArabic ? 'نوع الإجراء' : 'ACTION TYPE'}
            </div>
            <div className="grid grid-cols-4 gap-2">
              {[
                { id: 'shutdown' as ActionType, ar: 'إغلاق إجباري', en: 'Shutdown' },
                { id: 'restart' as ActionType, ar: 'إعادة تشغيل', en: 'Restart' },
                { id: 'lock' as ActionType, ar: 'قفل الشاشة', en: 'Lock' },
                { id: 'sleep' as ActionType, ar: 'سكون تام', en: 'Sleep' },
              ].map((opt) => {
                const isSelected = actionType === opt.id;
                return (
                  <button
                    key={opt.id}
                    type="button"
                    disabled={isRunning}
                    onClick={() => {
                      sounds.playClick();
                      setActionType(opt.id);
                    }}
                    className={`py-2 px-1 rounded-lg text-xs font-bold transition-all text-center cursor-pointer disabled:opacity-60 ${
                      isSelected
                        ? 'bg-[#e85933] text-white shadow-sm'
                        : 'bg-white border border-neutral-300 text-neutral-700 hover:bg-neutral-50 shadow-xs'
                    }`}
                  >
                    <span>{isArabic ? opt.ar : opt.en}</span>
                  </button>
                );
              })}
            </div>
          </div>

          {/* Big Orange Action Button (Exact replica of ↓ Download button in image) */}
          <div className="pt-0" dir={isArabic ? 'rtl' : 'ltr'}>
            <button
              type="button"
              onClick={handleToggleTimer}
              className={`w-full py-3 px-6 rounded-lg font-bold text-base flex items-center justify-center gap-2 text-white shadow-sm transition-all cursor-pointer active:scale-[0.99] ${
                isRunning
                  ? 'bg-neutral-800 hover:bg-neutral-900'
                  : 'bg-[#e85933] hover:bg-[#d54924]'
              }`}
            >
              {isRunning ? (
                <>
                  <RotateCcw className="w-4 h-4 text-red-400" />
                  <span>{isArabic ? 'إلغاء المؤقت' : 'Abort Timer'}</span>
                </>
              ) : (
                <>
                  <ArrowDown className="w-4 h-4" />
                  <span>{isArabic ? 'بدء المؤقت' : 'Start Timer'}</span>
                </>
              )}
            </button>
          </div>

          {/* Bottom Status Card (Exact replica of bottom card in image with progress bar) */}
          <div className="bg-white rounded-xl border border-neutral-200/90 p-3 shadow-xs space-y-2" dir={isArabic ? 'rtl' : 'ltr'}>
            <div className="text-xs text-neutral-600 font-medium">
              {isRunning ? (
                <div className="flex items-center justify-between">
                  <span>
                    {isArabic 
                      ? `قيد التشغيل — متبقي ${formatTime(remainingSeconds)}` 
                      : `Running — ${formatTime(remainingSeconds)} remaining`}
                  </span>
                  <span className="font-mono text-xs text-neutral-700">
                    {Math.round(progressPercent)}%
                  </span>
                </div>
              ) : (
                <span>
                  {isArabic ? 'جاهز — حدد الوقت والنوع واضغط على بدء المؤقت' : 'Ready — set duration and press Start Timer'}
                </span>
              )}
            </div>

            {/* Slim progress bar with orange thumb */}
            <div className="relative w-full h-1.5 bg-[#f0ede6] rounded-full overflow-hidden" dir="ltr">
              <div 
                className="h-full bg-[#e85933] rounded-full transition-all duration-300"
                style={{ width: `${isRunning ? Math.max(2, progressPercent) : 2}%` }}
              />
            </div>
          </div>

      </div>

      {/* Force Lock Screen Simulation Overlay */}
      {isLockScreenActive && (
        <LockScreen
          onUnlock={() => setIsLockScreenActive(false)}
          expectedPin={pinCode || '1234'}
          actionType={actionType}
          reason={isArabic ? 'انتهاء وقت المؤقت المحدد' : 'Scheduled Timer Expired'}
          isArabic={isArabic}
        />
      )}

      {/* Export EXE Modal */}
      <ExportExeModal
        isOpen={isExportModalOpen}
        onClose={() => setIsExportModalOpen(false)}
        config={currentConfig}
        isArabic={isArabic}
      />

    </div>
  );
}
