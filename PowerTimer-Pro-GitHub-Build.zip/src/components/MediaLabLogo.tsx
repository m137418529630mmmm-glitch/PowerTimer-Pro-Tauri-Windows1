import React from 'react';
import logoUrl from '../assets/medialab-logo.png';

interface MediaLabLogoProps { className?: string; }

export const MediaLabLogo: React.FC<MediaLabLogoProps> = ({ className = '' }) => (
  <div className={`inline-flex items-center select-none ${className}`}>
    <img src={logoUrl} alt="mediaLab publishing" className="h-10 sm:h-11 w-auto object-contain pointer-events-none" draggable={false} />
  </div>
);
