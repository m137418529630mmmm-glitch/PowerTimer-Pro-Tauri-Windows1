@echo off
setlocal
cd /d "%~dp0"
title PowerTimer Pro - Tauri Windows Builder
color 0B

echo ========================================================
echo          PowerTimer Pro - Windows EXE Builder
echo ========================================================
echo.

where node >nul 2>&1
if errorlevel 1 (
  echo [ERROR] Node.js is not installed.
  echo Install Node.js LTS, then run this file again.
  pause
  exit /b 1
)

where rustc >nul 2>&1
if errorlevel 1 (
  echo [ERROR] Rust is not installed or not in PATH.
  echo Install Rust from https://rustup.rs/ and choose the MSVC toolchain.
  echo Then reopen CMD and run this file again.
  pause
  exit /b 1
)

where cargo >nul 2>&1
if errorlevel 1 (
  echo [ERROR] Cargo is not installed or not in PATH.
  echo Reinstall Rust with the default MSVC toolchain.
  pause
  exit /b 1
)

echo [1/3] Checking Node dependencies...
if not exist "node_modules" (
  call npm install --no-audit --no-fund
  if errorlevel 1 goto :fail
) else (
  echo [OK] node_modules already exists - skipping npm install.
)

echo.
echo [2/3] Building frontend and Tauri application...
call npm run tauri:build
if errorlevel 1 goto :fail

echo.
echo [3/3] Opening installer folder...
if exist "src-tauri\target\release\bundle\nsis" (
  explorer "%cd%\src-tauri\target\release\bundle\nsis"
)
if exist "src-tauri\target\release\bundle\msi" (
  explorer "%cd%\src-tauri\target\release\bundle\msi"
)

echo.
echo ========================================================
echo [SUCCESS] PowerTimer Pro was built successfully.
echo ========================================================
echo.
echo NSIS installer: src-tauri\target\release\bundle\nsis
echo MSI installer : src-tauri\target\release\bundle\msi
echo.
pause
exit /b 0

:fail
echo.
echo ========================================================
echo [ERROR] Build failed. The window will stay open so you can
echo see the exact error above.
echo ========================================================
pause
exit /b 1
