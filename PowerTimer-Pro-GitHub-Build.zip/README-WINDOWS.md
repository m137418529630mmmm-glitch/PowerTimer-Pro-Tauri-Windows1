# PowerTimer Pro — Small Windows Build (Tauri)

This version uses **Tauri 2 instead of Electron**, so the installed app is much smaller. It keeps the same React/Tailwind UI and uses native Windows commands for Shutdown, Restart, Lock and Sleep.

## First build on Windows

1. Install Node.js LTS.
2. Install Rust with the default **MSVC** toolchain from https://rustup.rs/.
3. On Windows, install **Microsoft C++ Build Tools** (Desktop development with C++). WebView2 is normally already present on modern Windows 10/11.
4. Open this folder and double-click `build-windows.bat`.

The first Tauri build downloads Rust crates and may take several minutes. **Do not delete `node_modules` or `src-tauri/target`** if you want later builds to be faster.

## Output

- `src-tauri/target/release/bundle/nsis/` — normal Windows installer (`.exe`)
- `src-tauri/target/release/bundle/msi/` — MSI installer

There is no Electron runtime bundled, so the final application is substantially smaller than the previous Electron build.

## Runtime behavior

The timer is handled by the app. It does **not** schedule Windows `shutdown /t` at the beginning, so Windows will not show its "Windows will shut down in X minutes" notification when the timer starts. The Windows action is executed only when the countdown reaches zero.
