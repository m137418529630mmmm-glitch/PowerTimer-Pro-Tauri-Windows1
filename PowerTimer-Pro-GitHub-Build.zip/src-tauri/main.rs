fn main() {
    powertimer_pro_lib::run();
}
