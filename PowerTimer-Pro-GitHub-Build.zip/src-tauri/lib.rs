#![cfg_attr(not(debug_assertions), windows_subsystem = "windows")]

#[tauri::command]
fn execute_power_action(action: String, force_kill: bool) -> Result<(), String> {
    #[cfg(target_os = "windows")]
    {
        use std::process::Command;
        let force = if force_kill { Some("/f") } else { None };
        let result = match action.as_str() {
            "shutdown" => {
                let mut args = vec!["/s"];
                if let Some(f) = force { args.push(f); }
                args.extend(["/t", "0"]);
                Command::new("shutdown.exe").args(args).status()
            }
            "restart" => {
                let mut args = vec!["/r"];
                if let Some(f) = force { args.push(f); }
                args.extend(["/t", "0"]);
                Command::new("shutdown.exe").args(args).status()
            }
            "lock" => Command::new("rundll32.exe")
                .args(["user32.dll,LockWorkStation"])
                .status(),
            "sleep" => Command::new("powershell.exe")
                .args([
                    "-NoProfile", "-NonInteractive", "-WindowStyle", "Hidden",
                    "-Command",
                    "Add-Type -AssemblyName System.Windows.Forms; [System.Windows.Forms.Application]::SetSuspendState('Suspend', $false, $false)"
                ])
                .status(),
            _ => return Err(format!("Unknown action: {action}")),
        };
        match result {
            Ok(status) if status.success() => Ok(()),
            Ok(status) => Err(format!("Windows command failed with status: {status}")),
            Err(e) => Err(e.to_string()),
        }
    }
    #[cfg(not(target_os = "windows"))]
    {
        let _ = (action, force_kill);
        Err("This action is supported on Windows only.".into())
    }
}

#[tauri::command]
fn cancel_power_action() -> Result<(), String> {
    #[cfg(target_os = "windows")]
    {
        let status = std::process::Command::new("shutdown.exe")
            .args(["/a"])
            .status()
            .map_err(|e| e.to_string())?;
        if status.success() || status.code() == Some(1116) {
            Ok(())
        } else {
            Err(format!("Could not cancel shutdown: {status}"))
        }
    }
    #[cfg(not(target_os = "windows"))]
    { Err("This action is supported on Windows only.".into()) }
}

#[tauri::command]
fn app_version() -> String { "1.0.0".to_string() }

#[cfg_attr(mobile, tauri::mobile_entry_point)]
pub fn run() {
    tauri::Builder::default()
        .invoke_handler(tauri::generate_handler![execute_power_action, cancel_power_action, app_version])
        .run(tauri::generate_context!())
        .expect("error while running PowerTimer Pro");
}
